(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_26fed1ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_26fed1ad._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2a73f617._.js",
    "static/chunks/src_e1c332a5._.js",
    "static/chunks/node_modules_framer-motion_dist_es_92139a2a._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_index_208f44ab.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_index_d4b74329.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_9bb0cb41._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_a644e23c.js",
    "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_e8a320fa.js",
    "static/chunks/node_modules_lucide-react_dist_esm_3edf8e87._.js",
    "static/chunks/node_modules_111f86a6._.js"
  ],
  "source": "dynamic"
});
