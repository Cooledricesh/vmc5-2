(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/src_app_globals_b805903d.css",
    "static/chunks/node_modules_c4678127._.js",
    "static/chunks/node_modules_next_c9202ddd._.js",
    "static/chunks/node_modules_@clerk_shared_dist_93b52dbd._.js",
    "static/chunks/node_modules_swr_dist_24149bb6._.js",
    "static/chunks/node_modules_@clerk_clerk-react_dist_d2cac0f0._.js",
    "static/chunks/node_modules_@supabase_auth-js_dist_module_979ab755._.js",
    "static/chunks/node_modules_zod_v3_209a51fb._.js",
    "static/chunks/node_modules_f80d4490._.js",
    "static/chunks/src_49dcdf0a._.js"
  ],
  "source": "dynamic"
});
