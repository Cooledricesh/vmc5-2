(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_sign-up_[[___sign-up]]_page_tsx_3e96f111._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_sign-up_[[___sign-up]]_page_tsx_3e96f111._.js",
  "chunks": [
    "static/chunks/_6852c4a1._.js"
  ],
  "source": "dynamic"
});
